<link rel="icon" href="{{ asset('img/logo.png') }}">
