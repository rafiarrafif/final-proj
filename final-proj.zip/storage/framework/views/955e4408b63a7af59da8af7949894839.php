<div class="bg-nav"></div>
<div class="navbar">
    <a href="<?php echo e(route('home')); ?>" class="home">
        <i data-feather="home"
            style="stroke: <?php echo e(Request::is('/') || Request::is('plant*') ? '#b0a1fe' : '#848384'); ?>; width: 22px"></i>
    </a>
    <a href="<?php echo e(route('home')); ?>" class="home">
        <i data-feather="archive" style="stroke: #848384; width: 22px"></i>
    </a>
    <a href="<?php echo e(route('home')); ?>" class="home">
        <i data-feather="settings" style="stroke: #848384; width: 22px"></i>
    </a>
</div>
<?php /**PATH D:\Development\laragon\www\final-proj\resources\views/partials/navbar.blade.php ENDPATH**/ ?>