<?php

namespace App\Http\Controllers;

use App\Models\DataSensor;
use Illuminate\Http\Request;

class ViewController extends Controller
{
    public function index() {
        return view('home');
    }

    public function suhu() {
        $data = DataSensor::where('id', 1)->first();
        return $data->suhu;
    }

    public function getData() {
        $data = DataSensor::where('id', 1)->first();
        return response()->json($data);
    }
    
    public function addData($suhu, $kelembaban) {
        $data = DataSensor::where('id', 1)->first();
        $data->suhu = $suhu;
        $data->kelembaban = $kelembaban;
        $data->save();
    }
}