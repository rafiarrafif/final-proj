<?php $__env->startSection('content'); ?>
    <div class="bg-header" style="display: none"></div>
    <div class="fixed-header" style="display: none">
        <div class="title-plant">
            <span><?php echo e($plant->name); ?></span>
        </div>
    </div>
    <div class="main-content">
        <div class="main-spot">
            <div class="top-spot">
                <div class="content-main-spot">
                    <h1><?php echo e(intval($plant->temp)); ?><sup>°</sup></h1>
                    <span>Celcius</span>
                </div>
                <div class="img-main-spot">
                    <img src="<?php echo e(asset('img/plant_icon_2.png')); ?>">
                </div>
            </div>
        </div>
        <div class="main-card">
            <div class="top">

            </div>
            <hr class="lineup-plant" id="lineup-1">
            <div class="bottom">
                <div class="air content-bottom">
                    <div class="icon">
                        <i data-feather="wind" style="stroke: #d2d2d2; width: 18px"></i>
                    </div>
                    <div class="title">
                        <span>%<?php echo e($plant->air); ?></span>
                    </div>
                </div>
                <hr class="lineup-plant lineup-2">
                <div class="temp content-bottom">
                    <div class="icon">
                        <i data-feather="thermometer" style="stroke: #d2d2d2; width: 18px"></i>
                    </div>
                    <div class="title">
                        <span><?php echo e(intval($plant->fahrenheit)); ?> °F</span>
                    </div>
                </div>
                <hr class="lineup-plant lineup-2">
                <div class="soil content-bottom">
                    <div class="icon">
                        <i data-feather="archive" style="stroke: #d2d2d2; width: 18px"></i>
                    </div>
                    <div class="title">
                        <span>%<?php echo e($plant->soil); ?></span>
                    </div>
                </div>
            </div>
            <div class="show-more-btn">
                <span id="show-more-trigger">Lihat Selengkapnya</span>
                <span id="show-less-trigger">Tutup</span>
                <div class="icon">◢</div>
            </div>
        </div>
        <div class="just-dump" style="height: 1200px"></div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plants.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\laragon\www\final-proj\resources\views/plants/view.blade.php ENDPATH**/ ?>