<?php

use App\Http\Controllers\ViewController;
use Illuminate\Support\Facades\Route;

Route::get('/ptest', function () {
    return view('welcome');
});

Route::get('/', [ViewController::class, 'index'])->name('home');
Route::get('/api/bacasuhu', [ViewController::class, 'suhu'])->name('bacasuhu');
Route::get('/api/add-data/{suhu}/{kelembaban}', [ViewController::class, 'addData'])->name('addDataApi');
Route::post('/api/get-data', [ViewController::class, 'getData'])->name('getDataApi');