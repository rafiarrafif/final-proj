

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="header-title">
            <h1>Tambahkan Tanaman</h1>
        </div>
        <div class="content-form">
            <form action="<?php echo e(route('plant.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name">Nama Tanaman</label>
                    <input type="text" class="form-input" id="name" name="name" maxlength="100" required
                        placeholder="Masukkan nama tanaman">
                </div>
                <div class="form-group">
                    <label for="description">Catatan Tanaman</label>
                    <textarea class="form-input" id="description" name="notes" rows="4" maxlength="255"
                        placeholder="Masukkan deskripsi tanaman"></textarea>
                </div>
                <button type="submit" class="submit-btn">Submit</button>
                <a href="<?php echo e(route('home')); ?>" class="cancel-btn">Batalkan</a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plants.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\laragon\www\final-proj\resources\views/plants/create.blade.php ENDPATH**/ ?>