$(document).ready(function () {
    showMoreTrigger();
    titleFixed();

    $(window).on("scroll", function () {
        titleFixed();
    });

    $(window).on("resize", function () {
        showMoreTrigger();
    });
});

function titleFixed() {
    if (isElementAtTop("main-card")) {
        $(".fixed-header").fadeIn();
        $(".bg-header").fadeIn();
    } else {
        $(".fixed-header").fadeOut();
        $(".bg-header").fadeOut();
    }
}

function showMoreTrigger() {
    if (isDesktop()) {
        $(".show-more-btn").hide();
    } else {
        $(".show-more-btn").show();
        $("#show-less-trigger").hide();
    }
}

function isElementAtTop(elementId) {
    var elementTop = $("." + elementId).offset().top;
    var scrollTop = $(window).scrollTop();
    return elementTop <= scrollTop;
}

function isDesktop() {
    return window.innerWidth > 768;
}
